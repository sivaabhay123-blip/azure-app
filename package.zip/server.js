const express = require("express");
const bodyParser = require("body-parser");
const connectDB = require("./db");

const app = express();
app.use(bodyParser.json());
app.use(express.static("public"));

// Home route
app.get("/", (req, res) => {
  res.sendFile(__dirname + "/public/index.html");
});

// Get users
app.get("/users", async (req, res) => {
  const pool = await connectDB();
  const result = await pool.request().query("SELECT * FROM Users");
  res.json(result.recordset);
});

// Add user
app.post("/addUser", async (req, res) => {
  const { name, email } = req.body;
  const pool = await connectDB();

  await pool.request()
    .input("name", name)
    .input("email", email)
    .query("INSERT INTO Users (name, email) VALUES (@name, @email)");

  res.send("User added ✅");
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("Server running on port " + PORT));