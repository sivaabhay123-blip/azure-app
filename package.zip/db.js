const sql = require("mssql");

const config = {
  user: "musashi9846",
  password: "Abhay@9846",
  server: "bigmusashi.database.windows.net",
  database: "mydb",
  options: {
    encrypt: true,
    trustServerCertificate: false
  }
};

module.exports = async function connectDB() {
  try {
    const pool = await sql.connect(config);
    console.log("Connected to Azure SQL ✅");
    return pool;
  } catch (err) {
    console.error("DB Error ❌:", err);
  }
};